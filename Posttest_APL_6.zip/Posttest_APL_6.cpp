#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct Artis {
    string nama;
};

vector<Artis> artis_lagu_arab = {
    {"sherine"},
    {"nancy ajram"},
    {"amr diab"},
    {"maher zain"},
    {"ricky rich"}
};

bool login() {
    string username = "tendry";
    string password = "2309106116";
    string user_input, pass_input;
    int attempts = 0;

    while (attempts < 3) {
        cout << "Masukkan Nama: ";
        cin >> user_input;
        cout << "Masukkan NIM: ";
        cin >> pass_input;

        if (user_input == username && pass_input == password) {
            cout << "Login Berhasil!" << endl;
            return true;
        } else {
            attempts++;
            cout << "Login Gagal. Silakan coba lagi." << endl;
        }
    }

    cout << "Anda telah melebihi batas percobaan login. Program berhenti." << endl;
    return false;
}

char tampilkan_menu() {
    cout << "\nMenu:" << endl;
    cout << "1. Tambah data artis penyanyi" << endl;
    cout << "2. Tampilkan data artis penyanyi" << endl;
    cout << "3. Ubah data artis penyanyi" << endl;
    cout << "4. Hapus data artis penyanyi" << endl;
    cout << "5. Sorting" << endl;
    cout << "6. Searching" << endl;
    cout << "7. Keluar" << endl;

    char pilihan;
    cout << "Masukkan pilihan: ";
    cin >> pilihan;
    return pilihan;
}

// Sorting NIM Ganjil
void insertion_sort_huruf(vector<Artis>& data) {
    for (int i = 1; i < data.size(); ++i) {
        Artis key = data[i];
        int j = i - 1;
        while (j >= 0 && data[j].nama > key.nama) {
            data[j + 1] = data[j];
            j = j - 1;
        }
        data[j + 1] = key;
    }
}

void selection_sort_angka_desc(vector<Artis>& data) {
    for (int i = 0; i < data.size() - 1; ++i) {
        int max_idx = i;
        for (int j = i + 1; j < data.size(); ++j) {
            if (data[j].nama < data[max_idx].nama) {
                max_idx = j;
            }
        }
        swap(data[max_idx], data[i]);
    }
}

void bubble_sort(vector<Artis>& data) {
    for (int i = 0; i < data.size() - 1; ++i) {
        for (int j = 0; j < data.size() - i - 1; ++j) {
            if (data[j].nama > data[j + 1].nama) {
                swap(data[j], data[j + 1]);
            }
        }
    }
}

// Sorting NIM Genap
void selection_sort_huruf_desc(vector<Artis>& data) {
    for (int i = 0; i < data.size() - 1; ++i) {
        int max_idx = i;
        for (int j = i + 1; j < data.size(); ++j) {
            if (data[j].nama > data[max_idx].nama) {
                max_idx = j;
            }
        }
        swap(data[max_idx], data[i]);
    }
}

void bubble_sort_angka(vector<Artis>& data) {
    for (int i = 0; i < data.size() - 1; ++i) {
        for (int j = 0; j < data.size() - i - 1; ++j) {
            if (data[j].nama < data[j + 1].nama) {
                swap(data[j], data[j + 1]);
            }
        }
    }
}

void merge(vector<Artis>& data, int left, int middle, int right) {
    int n1 = middle - left + 1;
    int n2 = right - middle;

    vector<Artis> L(n1), R(n2);

    for (int i = 0; i < n1; ++i)
        L[i] = data[left + i];
    for (int j = 0; j < n2; ++j)
        R[j] = data[middle + 1 + j];

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        if (L[i].nama <= R[j].nama) {
            data[k] = L[i];
            ++i;
        } else {
            data[k] = R[j];
            ++j;
        }
        ++k;
    }

    while (i < n1) {
        data[k] = L[i];
        ++i;
        ++k;
    }

    while (j < n2) {
        data[k] = R[j];
        ++j;
        ++k;
    }
}

void merge_sort(vector<Artis>& data, int left, int right) {
    if (left >= right) {
        return;
    }

    int middle = left + (right - left) / 2;
    merge_sort(data, left, middle);
    merge_sort(data, middle + 1, right);
    merge(data, left, middle, right);
}

void sorting(vector<Artis>& data, bool is_odd) {
    if (is_odd) {
        insertion_sort_huruf(data);
        selection_sort_angka_desc(data);
        bubble_sort(data);
    } else {
        selection_sort_huruf_desc(data);
        bubble_sort_angka(data);
        merge_sort(data, 0, data.size() - 1);
    }
}

void tambah_data(vector<Artis>* ptr_artis) {
    Artis artis;
    cout << "Masukkan nama artis penyanyi baru: ";
    cin >> artis.nama;
    ptr_artis->push_back(artis); // Menggunakan dereference operator (*) untuk mengakses vektor melalui pointer
    cout << "Data artis penyanyi berhasil ditambahkan." << endl;
}

void tampilkan_data(vector<Artis>* ptr_artis) {
    cout << "\nDaftar artis penyanyi lagu Arab:" << endl;
    for (int i = 0; i < ptr_artis->size(); ++i) { // Menggunakan arrow operator (->) untuk mengakses member vektor melalui pointer
        cout << i + 1 << ". " << (*ptr_artis)[i].nama << endl; // Menggunakan dereference operator (*) untuk mengakses nilai pada vektor melalui pointer
    }
}

void ubah_data(vector<Artis>* ptr_artis) {
    tampilkan_data(ptr_artis);
    int index;
    cout << "Masukkan nomor artis penyanyi yang ingin diubah: ";
    cin >> index;
    index--;
    if (index >= 0 && index < ptr_artis->size()) {
        cout << "Masukkan nama artis penyanyi baru: ";
        cin >> (*ptr_artis)[index].nama; // Menggunakan dereference operator (*) untuk mengakses nilai pada vektor melalui pointer
        cout << "Data artis penyanyi berhasil diubah." << endl;
    } else {
        cout << "Nomor artis penyanyi tidak valid." << endl;
    }
}

void hapus_data(vector<Artis>* ptr_artis) {
    tampilkan_data(ptr_artis);
    int index;
    cout << "Masukkan nomor artis penyanyi yang ingin dihapus: ";
    cin >> index;
    index--;
    if (index >= 0 && index < ptr_artis->size()) {
        ptr_artis->erase(ptr_artis->begin() + index); // Menggunakan arrow operator (->) untuk mengakses member vektor melalui pointer
        cout << "Data artis penyanyi berhasil dihapus." << endl;
    } else {
        cout << "Nomor artis penyanyi tidak valid." << endl;
    }
}

bool validasi_pilihan(char pilihan) {
    return pilihan >= '1' && pilihan <= '7';
}

void tampilkan_menu_utama(vector<Artis>* ptr_artis) {
    char pilihan;
    do {
        pilihan = tampilkan_menu();

        if (!validasi_pilihan(pilihan)) {
            cout << "Pilihan tidak valid. Silakan pilih menu yang sesuai." << endl;
            continue;
        }

        switch (pilihan) {
            case '1':
                tambah_data(ptr_artis);
                break;
            case '2':
                tampilkan_data(ptr_artis);
                break;
            case '3':
                ubah_data(ptr_artis);
                break;
            case '4':
                hapus_data(ptr_artis);
                break;
            case '5': {
                cout << "Sorting:" << endl;
                cout << "1. NIM Ganjil" << endl;
                cout << "2. NIM Genap" << endl;
                cout << "Pilih jenis sorting: ";
                char sorting_option;
                cin >> sorting_option;

                if (sorting_option == '1') {
                    sorting(*ptr_artis, true);
                    cout << "Sorting untuk NIM Ganjil berhasil." << endl;
                } else if (sorting_option == '2') {
                    sorting(*ptr_artis, false);
                    cout << "Sorting untuk NIM Genap berhasil." << endl;
                } else {
                    cout << "Pilihan tidak valid." << endl;
                }
                break;
            }
            case '6':
                // Tambahkan implementasi untuk searching di sini
                break;
            case '7':
                cout << "Terima kasih! Program berhenti." << endl;
                break;
        }
    } while (pilihan != '7');
}

int main() {
    if (!login()) {
        return 0;
    }

    tampilkan_menu_utama(&artis_lagu_arab); // Mengirimkan alamat dari vektor artis_lagu_arab ke fungsi tampilkan_menu_utama

    return 0;
}
